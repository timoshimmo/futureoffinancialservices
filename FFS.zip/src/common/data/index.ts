
import { connectData, whatIsData, speakersData, numbersData, partnerImgsData, latestData, faqData, faqFullData, speakersFullData, agendaData } from "./FFSData";

export {
  connectData, 
  whatIsData,
  speakersData,
  numbersData,
  partnerImgsData,
  latestData,
  faqData,
  faqFullData,
  speakersFullData,
  agendaData
};
